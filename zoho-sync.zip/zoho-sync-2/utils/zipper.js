import archiver from "archiver";
import * as fs from "fs";

export function makeZip(path) {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(path)) {
      const zipPath = path.replace("csv", "zip");
      const output = fs.createWriteStream(zipPath);
      const archive = archiver("zip", {
        zlib: { level: 9 }, // Compression level
      });

      output.on("close", function () {
        resolve(zipPath);
      });

      archive.on("error", function (err) {
        reject(err);
      });

      archive.pipe(output);
      archive.append(fs.createReadStream(path), {
        name: path.split("/").pop(),
      });
      archive.finalize();
    } else {
      reject(new Error("Path does not exist"));
    }
  });
}
