import fs from "fs";
import readline from "readline";
import { parse } from "csv-parse";
import path from "path";

async function preprocessCsvFile(inputFile, outputFile) {
  const readInterface = readline.createInterface({
    input: fs.createReadStream(inputFile),
    output: fs.createWriteStream(outputFile),
    terminal: false,
  });

  for await (const line of readInterface) {
    const fixedLine = line.replace(
      /(?<!")"([^"]*)"(?!")/g,
      (_, match) => `"${match.replace(/"/g, '""')}"`
    );
    readInterface.output.write(fixedLine + "\n");
  }
}

const createNewFile = (currentWriteStream, outputBase, fileCounter, outputPath, headers) => {
  if (currentWriteStream) {
    currentWriteStream.end();
  }
  const fileName = `${outputBase}_${fileCounter}.csv`;
  const fullFilePath = path.join(outputPath, fileName);
  currentWriteStream = fs.createWriteStream(fullFilePath);
  fileCounter++;

  if (headers) {
    currentWriteStream.write(headers.join(";") + "\n");
  }

  return { currentWriteStream, fileCounter };
};

export const csvSplitter = (inputFile, tempDir, outputDir) => {
  return new Promise(async (resolve, reject) => {
    const tempFilePath = path.join(tempDir, "TEMP.CSV");

    // Ensure the temp-files directory exists
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
      console.log(`Created directory: ${tempDir}`);
    } else {
      console.log(`Directory already exists: ${tempDir}`);
    }

    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
      console.log(`Created directory: ${outputDir}`);
    } else {
      console.log(`Directory already exists: ${outputDir}`);
    }

    console.log("Preprocessing CSV file...");
    await preprocessCsvFile(inputFile, tempFilePath);
    console.log("Preprocessing Done");

    const maxRows = 24999;
    const outputPath = outputDir;
    const outputBase = "output";

    let fileCounter = 1;
    let rowCounter = 0;
    let headers = null;
    let currentWriteStream;

    fs.createReadStream(tempFilePath)
      .pipe(
        parse({
          delimiter: ";",
          trim: true,
          skipEmptyLines: true,
          columns: true,
          relax_quotes: true, // Helps with some quote issues
          relax_column_count: true, // Ignore extra columns
        })
      )
      .on("readable", function () {
        let record;
        while ((record = this.read()) !== null) {
          if (!headers) {
            headers = Object.keys(record);
            let x = createNewFile(currentWriteStream, outputBase, fileCounter, outputPath, headers);
            currentWriteStream = x.currentWriteStream;
            fileCounter = x.fileCounter;
          }

          if (rowCounter >= maxRows) {
            let y = createNewFile(currentWriteStream, outputBase, fileCounter, outputPath, headers);
            currentWriteStream = y.currentWriteStream;
            fileCounter = y.fileCounter;
            rowCounter = 0;
          }

          const rowString = headers
            .map((header, index, array) => {
              if (index === array.length - 1) {
                let value = record[header] || "";
                const match2 = value.match(/fs22\\?(\d*)\s(.+?)\\par/); // New regex pattern
                const match1 = value.match(/fs22 (.+?)\\par/); // Original regex pattern
                value = match2 ? match2[2] : (match1 ? match1[1] : ""); // Assign value based on which match is 
                return `"${value.replace(/"/g, '""')}"`; // Handle double quotes as before
              } else {
                return `"${(record[header] || "").replace(/"/g, '""')}"`;
              }
            })
            .join(";");
          currentWriteStream.write(rowString + "\n");

          rowCounter++;
        }
      })
      .on("end", () => {
        if (currentWriteStream) {
          currentWriteStream.end();
        }
        console.log("CSV file has been split successfully.");
        resolve();
      })
      .on("error", (error) => {
        console.error("Error in CSV stream:", error);
        if (currentWriteStream) {
          currentWriteStream.end();
        }
        reject(error);
      });
  });
};