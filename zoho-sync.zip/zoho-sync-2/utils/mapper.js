export function fieldMappers(type, fileId) {
  let resourceObject = {};
  let fieldMappings = [];
  if (type === "CLIENTI") {
    resourceObject = {
      type: "data",
      file_id: fileId,
      module: "Contacts",
      find_by: "Client_Code",
    };

    fieldMappings.push(
      {
        api_name: "codice",
        index: 0,
      },

      {
        api_name: "Client_Code",
        index: 1,
      },
      {
        api_name: "Last_Name",
        index: 2,
      },
      {
        api_name: "First_Name",
        index: 3,
      },
      {
        api_name: "Group",
        index: 4,
      },

      {
        api_name: "Card_Code",
        index: 5,
      },
      {
        api_name: "Mailing_Street",
        index: 6,
      },
      {
        api_name: "Mailing_City",
        index: 7,
      },
      {
        api_name: "Mailing_Zip",
        index: 8,
      },
      {
        api_name: "Mailing_Province",
        index: 9,
      },
      {
        api_name: "Mailing_State",
        index: 10,
      },
      {
        api_name: "Gender",
        index: 11,
      },
      {
        api_name: "Date_of_Birth",
        index: 12,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Mobile",
        index: 13,
      },
      {
        api_name: "Phone",
        index: 14,
      },
      {
        api_name: "Profession",
        index: 15,
      },
      {
        api_name: "Visual_Problem",
        index: 16,
      },
      {
        api_name: "Email",
        index: 17,
      },
      {
        api_name: "Mail",
        index: 18,
      },
      {
        api_name: "Letter",
        index: 19,
      },
      {
        api_name: "Use_Contact_Lenses",
        index: 20,
      },
      {
        api_name: "Hobby",
        index: 21,
      },
      {
        api_name: "Date_of_Insertion",
        index: 22,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Branch",
        index: 23,
      },
      {
        api_name: "SMS",
        index: 25,
      },
      {
        api_name: "Cognome_2",
        index: 25,
      },
      {
        api_name: "Head_of_Family",
        index: 26,
      },
      {
        api_name: "Head_of_Family_Card",
        index: 27,
      },
      {
        api_name: "Privacy_Date",
        index: 28,
      },
      {
        api_name: "Informed_Consent",
        index: 29,
      },
      {
        api_name: "Marketing_Consent",
        index: 30,
      },
      {
        api_name: "Profiling_Consent",
        index: 31,
      },
      {
        api_name: "Consentrev",
        index: 32,
      },
      {
        api_name: "Card",
        index: 33,
      }
    );
  } else if (type === "STORICOCARRELLO") {
    resourceObject = {
      type: "data",
      file_id: fileId,
      module: "Deals",
      find_by: "Code",
    };

    fieldMappings.push(
      {
        api_name: "Code",
        index: 0,
      },
      {
        api_name: "Deal_Name",
        index: 1,
      },
      {
        api_name: "Client_Code",
        index: 2,
      },
      {
        api_name: "Closing_Date",
        index: 3,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Description",
        index: 4,
      },
      {
        api_name: "Prezzo",
        index: 5,
      },
      {
        api_name: "Percentage_Discount",
        index: 6,
      },
      {
        api_name: "Sconto",
        index: 7,
      },
      {
        api_name: "Totale",
        index: 8,
      },
      {
        api_name: "Points1",
        index: 9,
      },
      {
        api_name: "Branch",
        index: 10,
      },
      {
        api_name: "Operator",
        index: 11,
      },
      {
        api_name: "Supply_Type1",
        index: 12,
      },
      {
        api_name: "Supply_Code",
        index: 13,
      },
      {
        api_name: "Stage",
        default_value: { value: "Closed Won" },
      },
      {
        api_name: "Contact_Name",
        index: 2,
        find_by: "Client_Code",
      },
      {
        api_name: "Cart_Code",
        index: 1,
      },
      {
        api_name: "Data_Scarico",
        index: 14,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Data_Pagamento",
        index: 15,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Promozione",
        index: 16,
      },
      {
        api_name: "Codice_a_Barre",
        index: 17,
      },
      {
        api_name: "Codice_Busta",
        index: 18,
      },
      {
        api_name: "codice_2_1",
        index: 20,
      }
    );
  } else if (type === "STORICOCARRELLO2") {
    resourceObject = {
      type: "data",
      file_id: fileId,
      module: "Price_Books",
      find_by: "Code",
    };

    fieldMappings.push(
      {
        api_name: "Code",
        index: 0,
      },
      {
        api_name: "Branch_Code",
        index: 1,
      },
      {
        api_name: "Client_Code",
        index: 2,
      },
      {
        api_name: "Cart_Code",
        index: 3,
      },
      {
        api_name: "Date",
        index: 4,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Ora",
        index: 5,
      },
      {
        api_name: "Barcode",
        index: 6,
      },
      {
        api_name: "Description",
        index: 7,
      },
      {
        api_name: "Lot",
        index: 8,
      },
      {
        api_name: "Quantity",
        index: 9,
      },
      {
        api_name: "Price",
        index: 10,
      },
      {
        api_name: "Percentage_Discount",
        index: 11,
      },
      {
        api_name: "Discount",
        index: 12,
      },
      {
        api_name: "Total",
        index: 13,
      },
      {
        api_name: "Vat1",
        index: 14,
      },
      {
        api_name: "Points",
        index: 15,
      },
      {
        api_name: "Branch",
        index: 16,
      },
      {
        api_name: "Operator",
        index: 17,
      },
      {
        api_name: "Supply_Type",
        index: 18,
      },
      {
        api_name: "Detail_Supply_Type",
        index: 19,
      },
      {
        api_name: "Supply_Code",
        index: 20,
      },
      {
        api_name: "Status",
        index: 21,
      },
      {
        api_name: "Paid",
        index: 22,
      },
      {
        api_name: "Turnover",
        index: 23,
      },
      {
        api_name: "Delivered",
        index: 24,
      },
      {
        api_name: "Warehouse",
        index: 25,
      },
      {
        api_name: "Payment_Date",
        index: 26,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Ora_Pagamento",
        index: 27,
      },
      {
        api_name: "Download_Date",
        index: 28,
        format: "dd/MM/yyyy",
      },
      {
        api_name: "Promotion",
        index: 29,
      },
      {
        api_name: "Supplier",
        index: 30,
      },
      {
        api_name: "Brand",
        index: 31,
      },
      {
        api_name: "Product_Type",
        index: 32,
      },
      {
        api_name: "Price_Book_Name",
        index: 1,
      },
      {
        api_name: "Deal",
        index: 3,
        find_by: "Cart_Code",
      },
      {
        api_name: "Contact",
        index: 2,
        find_by: "Client_Code",
      }
    );
  }
  resourceObject["field_mappings"] = fieldMappings;
  return resourceObject;
}
