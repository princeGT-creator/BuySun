import { promises as fs } from 'fs';
import path from 'path';

// Function to fetch the latest file paths for files starting with CLIENTE and STORICOCARRELLO
export const fetchLatestFilePaths = async (dir) => {
    let latestFiles = {
        CLIENTE: { path: null, time: 0 },
        STORICOCARRELLO: { path: null, time: 0 },
        STORICOCARRELLO2: { path: null, time: 0 },
    };

    const files = await fs.readdir(dir);

    for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = await fs.lstat(filePath);

        if (stat.isDirectory()) {
            const nestedLatestFiles = await fetchLatestFilePaths(filePath);
            // Compare and update latest CLIENTE file
            if (nestedLatestFiles.CLIENTE && nestedLatestFiles.CLIENTE.time > latestFiles.CLIENTE.time) {
                latestFiles.CLIENTE = nestedLatestFiles.CLIENTE;
            }
            // Compare and update latest STORICOCARRELLO file
            if (nestedLatestFiles.STORICOCARRELLO && nestedLatestFiles.STORICOCARRELLO.time > latestFiles.STORICOCARRELLO.time) {
                latestFiles.STORICOCARRELLO = nestedLatestFiles.STORICOCARRELLO;
            }

            if (nestedLatestFiles.STORICOCARRELLO2 && nestedLatestFiles.STORICOCARRELLO2.time > latestFiles.STORICOCARRELLO2.time) {
                latestFiles.STORICOCARRELLO2 = nestedLatestFiles.STORICOCARRELLO2;
            }
        } else {
            // Check if file name starts with CLIENTE
            if (file.startsWith('CLIENTI') && stat.mtimeMs > latestFiles.CLIENTE.time) {
                latestFiles.CLIENTE = { path: filePath, time: stat.mtimeMs };
            }
            // Check if file name starts with STORICOCARRELLO
            if (file.startsWith('STORICOCARRELLO') && !file.startsWith('STORICOCARRELLO22') && stat.mtimeMs > latestFiles.STORICOCARRELLO.time) {
                latestFiles.STORICOCARRELLO = { path: filePath, time: stat.mtimeMs };
            }

            if (file.startsWith('STORICOCARRELLO22') && stat.mtimeMs > latestFiles.STORICOCARRELLO2.time) {
                latestFiles.STORICOCARRELLO2 = { path: filePath, time: stat.mtimeMs };
            }
        }
    }

    return {
        CLIENTE: latestFiles.CLIENTE.path,
        STORICOCARRELLO: latestFiles.STORICOCARRELLO.path,
        STORICOCARRELLO2: latestFiles.STORICOCARRELLO2.path
    };
};

export const fetchLatestFiles = async (dir, count = 3) => {
    try {
        const files = await fs.readdir(dir);
        const fileDetails = await Promise.all(files.map(async (file) => {
            const filePath = path.join(dir, file);
            const stat = await fs.stat(filePath);
            return { filePath, mtime: stat.mtime };
        }));

        // Sort files by modification time, descending
        fileDetails.sort((a, b) => b.mtime - a.mtime);

        // Get the latest `count` files
        return fileDetails.slice(0, count).map(file => file.filePath);
    } catch (error) {
        console.error(`Error fetching latest files from ${dir}:`, error);
        throw error;
    }
};