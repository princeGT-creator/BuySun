import { promises as fs } from 'fs';
import path from 'path';

export const deleteDirectory = async (dirPath) => {
    try {
        const files = await fs.readdir(dirPath);
        await Promise.all(files.map(async (file) => {
            const filePath = path.join(dirPath, file);
            const stat = await fs.lstat(filePath);

            if (stat.isDirectory()) {
                await deleteDirectory(filePath);
            } else {
                await fs.unlink(filePath);
            }
        }));
        await fs.rmdir(dirPath);
        console.log(`Directory ${dirPath} deleted successfully.`);
    } catch (error) {
        console.error(`Error deleting directory ${dirPath}:`, error);
        throw error;
    }
};
