
# Buysun Zoho Sync

This project synchronizes files from the local filesystem to Zoho CRM via scheduled tasks and emergency endpoints. It processes CSV files, splits them, and uploads them to Zoho CRM using the bulk write API.

## Prerequisites

- Node.js
- npm (Node Package Manager)
- Zoho CRM account
- Environment variables set up in a `.env` file

## Server Requirements

- 2 GB RAM
- 15 - 20 GB Storage (recommended)


## Setup

### Environment Variables

Create a `.env` file in the root directory and add the following variables:

```env
CLIENT_ID=your_client_id
CLIENT_SECRET=your_client_secret
REDIRECT_URI=your_redirect_uri
BASE_ACCOUNT_URL=your_base_account_url
DOMAIN=your_zoho_domain
CODE=your_authorization_code
DIRECTORY_PATH=path_of_your_ftp_directory
```
### Refresh Token

Create a new ref_token.txt file in the root directory and add the refresh token inside it 

## Installation

1. Clone the repository:

    ```bash
    git clone https://github.com/your-username/buysun-zoho-sync.git
    cd buysun-zoho-sync
    ```

2. Install the dependencies:

    ```bash
    npm install
    ```

## Running the Project

To run the JavaScript version, ensure your source files are in JavaScript and execute:

```bash
node server.js
```

### Running with PM2

To run the project using PM2 for process management, follow these steps:

1. Install PM2 globally:

    ```bash
    npm install pm2 -g
    ```

2. Start the application with PM2:

    ```bash
    pm2 start server.js --name buysun-zoho-sync
    ```

3. To monitor the application:

    ```bash
    pm2 logs buysun-zoho-sync
    ```

4. To restart the application:

    ```bash
    pm2 restart buysun-zoho-sync
    ```

5. To stop the application:

    ```bash
    pm2 stop buysun-zoho-sync
    ```

### Generating a Let's Encrypt Certificate with Nginx

To secure your application with HTTPS using Let's Encrypt and Nginx, follow these steps:

1. Install Certbot and the Certbot Nginx plugin:

    On Ubuntu:

    ```bash
    sudo apt-get update
    sudo apt-get install certbot python3-certbot-nginx
    ```

2. Obtain the certificate:

    ```bash
    sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
    ```

3. Certbot will automatically update your Nginx configuration. Ensure your Nginx configuration file looks similar to this:

    ```nginx
    server {
        listen 80;
        server_name yourdomain.com www.yourdomain.com;

        location / {
            proxy_pass http://localhost:3000;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }
    }

    server {
        listen 443 ssl;
        server_name yourdomain.com www.yourdomain.com;

        ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
        ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
        include /etc/letsencrypt/options-ssl-nginx.conf;
        ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;

        location / {
            proxy_pass http://localhost:3000;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }
    }
    ```

4. Renew the certificates automatically:

    ```bash
    sudo crontab -e
    ```

    Add the following line to the crontab to renew the certificates automatically every 12 hours:

    ```bash
    0 */12 * * * certbot renew --quiet
    ```

## Endpoints

### Receive Webhook

```http
POST /webhook
```
Receives data from Zoho CRM and logs it.

### Emergency Sync

```http
GET /emergency-hit
```
Processes the latest files and uploads them to Zoho CRM immediately.

### Delete Logs

```http
GET /delete-logs
```
Deletes all webhook logs.

### Display Webhook Logs

```http
GET /wb-logs
GET /wb-logs-2
```
Displays the latest webhook logs.

## Scheduled Jobs

1. Deletes logs older than 1 day every hour.
2. Syncs files to Zoho CRM daily at 3 AM.


## Utility Functions

### fetch-files.ts

Contains functions to fetch the latest file paths and files.

### csv-splitter.ts

Contains functions to split CSV files.

### mapper.ts

Contains functions to map fields for Zoho CRM.

### zipper.ts

Contains functions to create ZIP files.

### delete-dir.ts

Contains functions to delete directories.

## Dependencies

- express
- body-parser
- node-schedule
- axios
- form-data
- dotenv
- fs

## License

This project is licensed under the MIT License.

## Author

Ryaz.io Technologies
