import express from 'express';
import bodyParser from 'body-parser';
import schedule from 'node-schedule';
import { fetchLatestFilePaths, fetchLatestFiles } from './utils/fetch-files.js';
import path from 'path';
import { csvSplitter } from './utils/csv-splitter.js';
import * as dotenv from "dotenv";
import axios from "axios";
import FormData from "form-data";
import { fieldMappers } from './utils/mapper.js';
import { makeZip } from './utils/zipper.js';
import * as fs from 'fs';

import { deleteDirectory } from './utils/delete-dir.js';

dotenv.config();

const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Store the webhook logs
let webhookLogs = [];

const generateRefresh = async () => {
    const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    };

    const payload = new URLSearchParams({
        code: process.env.CODE, // Make sure these environment variables are set
        redirect_uri: process.env.REDIRECT_URI,
        client_id: process.env.CLIENT_ID,
        client_secret: process.env.CLIENT_SECRET,
        grant_type: "authorization_code",
    }).toString();

    const url = process.env.BASE_ACCOUNT_URL;

    try {
        const response = await axios.post(url, payload, { headers });
        console.log("resp", response); // Log the response
        fs.writeFileSync("ref_token", response.data["refresh_token"]);
    } catch (error) {
        console.error(
            "Error making the request or writing the token file: ",
            error
        );
    }
};

const generateAccessToken = async () => {
    //read refresh token from file
    const headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    };

    let token = "";
    try {
        token = fs.readFileSync("ref_token.txt", "utf8").replace(/\n/g, "");
    } catch (err) {
        console.error("Error reading the token file: ", err);
        return;
    }

    const url = process.env.BASE_ACCOUNT_URL; // Ensure you have these environment variables set

    const payload = new URLSearchParams({
        refresh_token: token,
        redirect_uri: process.env.REDIRECT_URI,
        client_id: process.env.CLIENT_ID,
        client_secret: process.env.CLIENT_SECRET,
        grant_type: "refresh_token",
    }).toString();

    try {
        const response = await axios.post(url, payload, { headers });
        return response.data["access_token"];
    } catch (error) {
        console.error("Error making the request: ", error);
    }
};

const getOrgId = async (accessToken) => {
    const url = `https://www.zohoapis.${process.env.DOMAIN}/crm/v6/org`;

    const headers = {
        Authorization: `Zoho-oauthtoken ${accessToken}`,
    };

    try {
        const response = await axios.get(url, { headers });
        if (response.data) {
            return response.data.org[0].zgid;
        }
    } catch (error) {
        console.error("Error fetching the organization ID: ", error);
        return null;
    }
};

const fileUpload = async (accessToken, zipPath) => {
    const orgId = await getOrgId(accessToken);

    if (!orgId) {
        console.error("Failed to retrieve Organization ID.");
        return;
    }

    const url = `https://content.zohoapis.${process.env.DOMAIN}/crm/v2/upload`;

    const headers = {
        Authorization: `Zoho-oauthtoken ${accessToken}`,
        feature: "bulk-write",
        "X-CRM-ORG": orgId,
    };

    const form = new FormData();
    form.append("file", fs.createReadStream(zipPath), {
        filename: zipPath,
        contentType: "application/zip",
    });

    try {
        const response = await axios.post(url, form, {
            headers: {
                ...headers,
                ...form.getHeaders(), // This spreads the form-data headers as well
            },
        });

        if (response.data) {
            console.log("HTTP Status Code : " + response.status);
            console.log(response.data);
            return response.data.details.file_id;
        }
    } catch (error) {
        console.error(
            "Error uploading the file: ",
            error.response ? error.response.data : error.message
        );
    }
};

const bulkWrite = async (accessToken, path, type) => {
    return new Promise(async (resolve, reject) => {
        try {
            const zipPath = await makeZip(path);
            const fileId = await fileUpload(accessToken, zipPath);
            const headers = {
                Authorization: `Zoho-oauthtoken ${accessToken}`,
                "Content-Type": "application/json",
            };
            const callback = {
                url: process.env.REDIRECT_URL,
                method: "post",
            };
            const requestBody = {
                operation: "upsert",
                ignore_empty: true,
                callback: callback,
                character_encoding: "ISO-8859-1",
            };
            const resource_object = fieldMappers(type, fileId);
            const resource = [resource_object];
            requestBody["resource"] = resource;

            const bulkUrl = `https://www.zohoapis.${process.env.DOMAIN}/crm/bulk/v2/write`;

            const response = await axios.post(bulkUrl, requestBody, { headers });
            console.log(response.data);
            resolve();
            return response;
        } catch (error) {
            console.log(error);
            reject();
        }
    });
}

// Endpoint to receive webhook
app.post('/webhook', (req, res) => {
    const webhookEntry = {
        id: Date.now(), // unique ID based on timestamp
        data: req.body,
        receivedAt: new Date()
    };
    webhookLogs.push(webhookEntry);
    console.log('Webhook received:', webhookEntry);
    res.status(200).send('Webhook received');
});

app.get('/', (req, res) => {
    res.status(200).send('Buysun zoho sync')
})

app.get('/emergency-hit', async (req, res) => {
    try {
        const dirPath = path.resolve(process.env.DIRECTORY_PATH);
        const filePaths = await fetchLatestFilePaths(dirPath);
        console.log(filePaths);
        await csvSplitter(filePaths.CLIENTE, './temp-clienti', './clienti-output');
        await csvSplitter(filePaths.STORICOCARRELLO, './temp-storicocarrello', './storicocarrello-output');
        await csvSplitter(filePaths.STORICOCARRELLO2, './temp-storicocarrello2', './storicocarrello2-output');

        const accessToken = await generateAccessToken();
        if (!accessToken) {
            console.error("Error generating access token");
            return;
        }

        const clientiFiles = await fetchLatestFiles('./clienti-output', 2);

        console.log(clientiFiles);
        const clientiPromises = clientiFiles.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "CLIENTI"
            )
        })
        await Promise.all(clientiPromises);

        const storicoFiles = await fetchLatestFiles('./storicocarrello-output', 2);
        console.log('storico', storicoFiles);

        const storicoPromises = storicoFiles.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "STORICOCARRELLO"
            )
        })
        await Promise.all(storicoPromises);

        const storico2Files = await fetchLatestFiles('./storicocarrello2-output', 2);
        console.log('storico2', storico2Files);

        const storico2Promises = storico2Files.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "STORICOCARRELLO2"
            )
        })

        await Promise.all(storico2Promises);

    } catch (error) {
        console.error('Error', error);
    } finally {
        (async () => {
            await deleteDirectory('./clienti-output');
            await deleteDirectory('./storicocarrello-output');
            await deleteDirectory('./temp-clienti');
            await deleteDirectory('./temp-storicocarrello');
            await deleteDirectory('./storicocarrello2-output');
            await deleteDirectory('./temp-storicocarrello2');
        })();
    }
})

app.get('/delete-logs', (req, res) => {
    webhookLogs = [];
    res.status(200).json(webhookLogs);
})

app.get('/wb-logs-2', (req, res) => {
    res.status(200).json(webhookLogs);
})

// Endpoint to display webhook logs
app.get('/wb-logs', (req, res) => {
    const latestLog = webhookLogs.length > 0 ? webhookLogs[webhookLogs.length - 1] : null;
    const logsHtml = latestLog ? `
        <div>
            <h2>Log ID: ${latestLog.id}</h2>
            <p><strong>Received At:</strong> ${latestLog.receivedAt}</p>
            <pre>${JSON.stringify(latestLog.data, null, 2)}</pre>
        </div>
    ` : '<h1>No webhook data received yet.</h1>';

    const sidebarHtml = webhookLogs.reverse().map((log, index) => `
        <li id="log-${log.id}" class="sidebar-item" data-log-index="${index}">
            <a href="#">${log.receivedAt.toISOString()}</a>
        </li>
    `).join('');

    res.send(`
        <html>
            <head>
                <style>
                    body { display: flex; }
                    .sidebar { width: 200px; padding: 20px; background: #f0f0f0; }
                    .content { margin-left: 220px; padding: 20px; }
                    .sidebar-item { padding: 10px; cursor: pointer; }
                    .sidebar-item.active { background: #d0d0d0; }
                </style>
            </head>
            <body>
                <div class="sidebar">
                    <h1>Webhook Logs</h1>
                    <ul>
                        ${sidebarHtml}
                    </ul>
                </div>
                <div class="content" id="log-content">
                    ${logsHtml}
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const logs = ${JSON.stringify(webhookLogs)};
                        const sidebarItems = document.querySelectorAll('.sidebar-item');
                        const logContent = document.getElementById('log-content');
                        
                        sidebarItems.forEach(item => {
                            item.addEventListener('click', () => {
                                const index = item.getAttribute('data-log-index');
                                const log = logs[index];
                                sidebarItems.forEach(i => i.classList.remove('active'));
                                item.classList.add('active');
                                logContent.innerHTML = \`
                                    <div>
                                        <h2>Log ID: \${log.id}</h2>
                                        <p><strong>Received At:</strong> \${log.receivedAt}</p>
                                        <pre>\${JSON.stringify(log.data, null, 2)}</pre>
                                    </div>
                                \`;
                            });
                        });
                        if (sidebarItems.length > 0) {
                            sidebarItems[sidebarItems.length - 1].classList.add('active');
                        }
                    });
                </script>
            </body>
        </html>
    `);
});

// Scheduler to delete logs older than 1 day
schedule.scheduleJob('0 * * * *', () => {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    webhookLogs = webhookLogs.filter(log => log.receivedAt > oneDayAgo);
    console.log('Old logs deleted');
});

schedule.scheduleJob('0 3 * * *', async () => {
    try {
        const dirPath = path.resolve(process.env.DIRECTORY_PATH);
        const filePaths = await fetchLatestFilePaths(dirPath);
        console.log(filePaths);
        await csvSplitter(filePaths.CLIENTE, './temp-clienti', './clienti-output');
        await csvSplitter(filePaths.STORICOCARRELLO, './temp-storicocarrello', './storicocarrello-output');
        await csvSplitter(filePaths.STORICOCARRELLO2, './temp-storicocarrello2', './storicocarrello2-output');

        const accessToken = await generateAccessToken();
        if (!accessToken) {
            console.error("Error generating access token");
            return;
        }

        const clientiFiles = await fetchLatestFiles('./clienti-output', 2);

        console.log(clientiFiles);
        const clientiPromises = clientiFiles.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "CLIENTI"
            )
        })
        await Promise.all(clientiPromises);

        const storicoFiles = await fetchLatestFiles('./storicocarrello-output', 2);
        console.log('storico', storicoFiles);

        const storicoPromises = storicoFiles.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "STORICOCARRELLO"
            )
        })
        await Promise.all(storicoPromises);

        const storico2Files = await fetchLatestFiles('./storicocarrello2-output', 2);
        console.log('storico2', storico2Files);

        const storico2Promises = storico2Files.reverse().map(async (file) => {
            return await bulkWrite(
                accessToken,
                file,
                "STORICOCARRELLO2"
            )
        })

        await Promise.all(storico2Promises);

    } catch (error) {
        console.error('Error', error);
    } finally {
        (async () => {
            await deleteDirectory('./clienti-output');
            await deleteDirectory('./storicocarrello-output');
            await deleteDirectory('./temp-clienti');
            await deleteDirectory('./temp-storicocarrello');
            await deleteDirectory('./storicocarrello2-output');
            await deleteDirectory('./temp-storicocarrello2');
        })();
    }
});

// Start the server
app.listen(port, '0.0.0.0', () => {
    console.log(`Server is running on http://0.0.0.0:${port}`);
});